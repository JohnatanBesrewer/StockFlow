from __future__ import annotations
from uuid import UUID, uuid7
from decimal import Decimal
import datetime
import sqlite3
import entities
import validator
import database

# update_price
# add_barcode
# delete_product
# update_name
# remove_barcode


class ProductRepository:

    _PRODUCT_SELECT = """
        SELECT
            p.product_id,
            p.name,
            p.unit,
            p.created_at,

            (
                SELECT b.barcode
                FROM barcodes b
                WHERE b.product_id = p.product_id
                ORDER BY b.created_at ASC
                LIMIT 1
            ) AS primary_barcode,

            (
                SELECT sp.price
                FROM sale_prices sp
                WHERE sp.product_id = p.product_id
                AND sp.valid_to IS NULL
                ORDER BY sp.valid_from DESC
                LIMIT 1
            ) AS active_price

        FROM products p
        """

    def __init__(self, db: database.Database) -> None:
        self._db = db

    @staticmethod
    def _normalize_query(query: str) -> str:
        """
        Превращает пользовательский ввод в безопасный FTS5-запрос.
        Удаляет недопустимые символы, добавляет префиксный поиск.
        """

        if not query:
            return ""

        # 1. Удаляем символы, которые ломают FTS5
        # % _ " ' : ( ) + - < > = ~ ^ |
        bad_chars = "%_\"'():+-<>~=^|"
        cleaned = query.translate({ord(c): " " for c in bad_chars})

        # 2. Разбиваем на слова
        parts = [p.strip() for p in cleaned.split() if p.strip()]

        if not parts:
            return ""

        # 3. Префиксный поиск
        tokens = [f"{p}*" for p in parts]

        # 4. Соединяем через AND
        return " AND ".join(tokens)

    def create(
        self,
        product: entities.Product,
    ) -> None:
        """
        Сохраняет новый  Product. Вставляет строки в таблицы:
        - products (product_id, name, unit, created_at),
        - barcodes (barcode, product_id, created_at),
        - sale_prices (price_id, product_id, price, valid_from)
        """

        product_id_str = str(product.product_id)
        created_at_str = product.created_at.astimezone(datetime.UTC).isoformat()

        with self._db.transaction() as conn:

            conn.execute(
                """
                INSERT INTO products (
                    product_id, name, unit, created_at
                )
                VALUES (?, ?, ?, ?)
                """,
                (
                    product_id_str,
                    product.name,
                    product.unit.value,
                    created_at_str,
                ),
            )

            # 3. Вставка в barcodes
            conn.execute(
                """
                INSERT INTO barcodes (barcode, product_id, created_at)
                VALUES (?, ?, ?)
                """,
                (
                    product.primary_barcode,
                    product_id_str,
                    created_at_str,
                ),
            )

            # 4. Вставка в sale_prices
            price_id = uuid7()  # репозиторий может генерировать только свои ключи
            conn.execute(
                """
                INSERT INTO sale_prices (price_id, product_id, price, valid_from, valid_to)
                VALUES (?, ?, ?, ?, NULL)
                """,
                (
                    str(price_id),
                    product_id_str,
                    int(product.sale_price * 100),  # Decimal → INTEGER
                    created_at_str,
                ),
            )

    def _build_product_from_row(self, row: sqlite3.Row) -> entities.Product:
        """
        Единый mapper для сборки _Product из строки.
        Используется и в get_by_id(), и в search_by_name().
        """

        product_id = row["product_id"]

        # Проверки целостности
        if row["primary_barcode"] is None:
            raise RuntimeError(
                f"Product {product_id} exists but has no barcodes — нарушена целостность данных"
            )

        if row["active_price"] is None:
            raise RuntimeError(
                f"Product {product_id} exists but has no active price — нарушена целостность данных"
            )

        return entities.Product(
            product_id=UUID(product_id),
            primary_barcode=row["primary_barcode"],
            name=row["name"],
            unit=entities.Unit(row["unit"]),
            sale_price=Decimal(row["active_price"]) / Decimal("100"),
            created_at=datetime.datetime.fromisoformat(row["created_at"]),
        )

    def get_by_id(
        self,
        product_id: UUID | str,
    ) -> entities.Product | None:

        sql = self._PRODUCT_SELECT + """
            WHERE p.product_id = ?
            """

        with self._db.read_connection() as conn:
            row = conn.execute(
                sql,
                (str(product_id),),
            ).fetchone()

        if row is None:
            return None

        return self._build_product_from_row(row)

    def get_by_barcode(self, barcode: str) -> entities.Product | None:
        """
        Возвращает _Product по barcode или None, если не найден.
        Находит product_id в barcodes, затем вызывает get_by_id(product_id).
        """
        with self._db.read_connection() as conn:
            row = conn.execute(
                """
                SELECT product_id
                FROM barcodes
                WHERE barcode = ?
                LIMIT 1
                """,
                (barcode,),
            ).fetchone()

        if row is None:
            return None

        return self.get_by_id(UUID(row["product_id"]))

    def search_by_name(
        self,
        query: str,
        limit: int | None = None,
    ) -> list[entities.Product]:

        normalized = self._normalize_query(query)

        if not normalized:
            return []

        sql = self._PRODUCT_SELECT + """
            JOIN product_search s
                ON s.product_id = p.product_id

            WHERE s.name MATCH ?

            ORDER BY bm25(product_search)
            """
        params: list[str | int] = [normalized]

        if limit is not None:
            sql += " LIMIT ?"
            params.append(limit)

        with self._db.transaction() as conn:
            rows = conn.execute(
                sql,
                params,
            ).fetchall()

        return [self._build_product_from_row(row) for row in rows]

    # def set_sale_price(
    #     self,
    #     product_id: UUID | str,
    #     new_price: Decimal,
    #     now: datetime.datetime | None = None,
    # ) -> None:
    #     """
    #     Основная бизнес-логика: управление историей цен товара через механизм временных интервалов.
    #     Реализует паттерн "Valid Time Period" для отслеживания изменений цен во времени.

    #     Зачем нужно:
    #     - Сохраняет историю всех ценовых изменений
    #     - Гарантирует, что в любой момент времени активна только одна цена
    #     - Позволяет восстанавливать исторические цены
    #     - Обеспечивает целостность данных при параллельных операциях

    #     Почему именно так:
    #     Использование NULL для valid_to обозначает "бесконечность" - текущая активная цена.
    #     """

    #     # === 1. Подготовка временной метки ===
    #     if now is None:
    #         now = datetime.datetime.now(
    #             datetime.UTC
    #         )  # Используем UTC по умолчанию для глобальной согласованности

    #     # Проверка временной зоны КРИТИЧЕСКИ важна:
    #     # - Без часового пояса невозможно корректно сравнивать временные метки
    #     # - Предотвращает ошибки при работе в распределенных системах
    #     if now.tzinfo is None:
    #         raise ValueError(
    #             "now must be timezone-aware"
    #         )  # Явная ошибка лучше скрытых багов

    #     now_utc = now.astimezone(
    #         datetime.UTC
    #     )  # Приводим к UTC даже если передали другую зону
    #     now_iso = (
    #         now_utc.isoformat()
    #     )  # Используем ISO-формат для совместимости с SQLite

    #     # === 2. Обработка цены ===
    #     # Валидация по бизнес-правилам
    #     validated = validator.validate_price(new_price)

    #     # Конвертация в копейки/центы:
    #     # - Избегаем проблем с плавающей точкой (0.1 + 0.2 != 0.3 в float)
    #     # - Стандартная практика для финансовых систем
    #     # - Позволяет хранить цену как INTEGER в SQLite (более эффективно)
    #     price_cents = int(validated * Decimal("100"))

    #     # === 3. Нормализация идентификатора ===
    #     product_id_str = str(
    #         product_id
    #     )  # Приводим к строке для единообразия в запросах

    #     # === 4. Транзакция БД ===
    #     with self._db.transaction() as conn:  # Автоматическая коммит/откат при выходе из блока
    #         # --- Проверка 1: Существует ли товар ---
    #         exists = conn.execute(
    #             "SELECT 1 FROM products WHERE product_id = ?",
    #             (product_id_str,),
    #         ).fetchone()

    #         if exists is None:
    #             # Критическая ошибка - нельзя менять цену несуществующему товару
    #             # Это защита от логических ошибок в вызывающем коде
    #             raise RuntimeError(f"Product {product_id} does not exist")

    #         # --- Проверка 2: Наличие активной цены ---
    #         active = conn.execute(
    #             """
    #             SELECT price_id, price, valid_from
    #             FROM sale_prices
    #             WHERE product_id = ?
    #             AND valid_to IS NULL  -- NULL = активная цена
    #             ORDER BY valid_from DESC  -- На случай дубликатов берем самую свежую
    #             LIMIT 1
    #             """,
    #             (product_id_str,),
    #         ).fetchone()

    #         if active is None:
    #             # СИСТЕМНАЯ ОШИБКА - нарушена бизнес-логика:
    #             # По требованиям у каждого товара должна быть активная цена
    #             # Возможные причины:
    #             # 1. Ошибка при первоначальном создании товара
    #             # 2. Параллельное удаление цены
    #             # 3. Сбой в предыдущих операциях
    #             raise RuntimeError(
    #                 f"Product {product_id} has no active price — нарушена целостность данных"
    #             )

    #         # --- Шаг 3: Деактивация старой цены ---
    #         # Закрываем предыдущую цену, фиксируя момент окончания действия
    #         conn.execute(
    #             """
    #             UPDATE sale_prices
    #             SET valid_to = ?  -- Устанавливаем время окончания
    #             WHERE price_id = ?
    #             """,
    #             (now_iso, active["price_id"]),
    #         )
    #         # Почему не DELETE?
    #         # - Сохраняем историю изменений
    #         # - Возможность аудита
    #         # - Восстановление предыдущих цен

    #         # --- Шаг 4: Создание новой цены ---
    #         new_price_id = str(uuid7())  # Генерация временно-упорядоченного UUID
    #         # Почему uuid7?
    #         # - Встроенный порядок по времени (первые байты = timestamp)
    #         # - Лучше для индексов в БД по сравнению с случайными UUID
    #         # - Совместимость с современными стандартами (RFC-9562)

    #         conn.execute(
    #             """
    #             INSERT INTO sale_prices (
    #                 price_id,
    #                 product_id,
    #                 price,       -- хранится в копейках как INTEGER
    #                 valid_from,  -- время начала действия
    #                 valid_to     -- NULL = активная цена
    #             )
    #             VALUES (?, ?, ?, ?, NULL)
    #             """,
    #             (
    #                 new_price_id,
    #                 product_id_str,
    #                 price_cents,  # Сохраняем как целое число копеек
    #                 now_iso,  # Время начала действия новой цены
    #             ),
    #         )
    #         # Почему NULL для valid_to?
    #         # - Стандартный паттерн "open end" в исторических таблицах
    #         # - Упрощает запросы на получение текущей цены
    #         # - Гарантирует, что всегда есть активная цена


repo = ProductRepository(database.db)

print(repo.get_by_id(UUID("019e7516-c8b0-7354-adb6-7aa3246b52ad")))
print(repo.get_by_barcode("2902376564248"))
print(repo.search_by_name("сухари"))

# product1 = entities.Product(
#     None,  # uuid7(),
#     None,  # validate_ean13(code: str) -> str
#     "Сухари чёрные",
#     entities.Unit.PIECE,
#     Decimal(120.50),
#     None,  # datetime.datetime.now(datetime.UTC),
# )

# repo.create(product1)

# product2 = entities.Product(
#     None,  # uuid7(),
#     None,  # validate_ean13(code: str) -> str
#     "Топор зелёныйй",
#     entities.Unit.METRE,
#     Decimal(15.55),
#     None,  # datetime.datetime.now(datetime.UTC),
# )

# repo.create(product2)


# def dump_table(db: database.Database, table: str):
#     with db.transaction() as conn:
#         rows = conn.execute(f"SELECT * FROM {table}").fetchall()
#         for row in rows:
#             print(dict(row))


# dump_table(database.db, "products")
# dump_table(database.db, "barcodes")
# dump_table(database.db, "sale_prices")
